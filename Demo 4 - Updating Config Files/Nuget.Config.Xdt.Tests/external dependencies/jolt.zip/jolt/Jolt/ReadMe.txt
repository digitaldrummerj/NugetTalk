The Jolt.NET libriares Jolt.Testing.Assertions.VisualStudio and Jolt.Automata.Glee both require external components that are not distributed with Jolt.NET (due to license restrictions and/or incompatibility).  In order for these libraries to run, you must obtain the following dependencies and place them in the same directory as the Jolt.NET library (or the global assembly cache).

Jolt.Automata.Glee requires:
Microsoft GLEE
http://research.microsoft.com/en-us/downloads/f1303e46-965f-401a-87c3-34e1331d32c5/default.aspx

Jolt.Testing.Assertions.VisualStudio requires;
Microsoft.VisualStudio.QualityTools.UnitTest.dll (Visual Studio 2008 Test Edition)
http://www.microsoft.com/visualstudio/en-us/products/teamsystem/default.mspx