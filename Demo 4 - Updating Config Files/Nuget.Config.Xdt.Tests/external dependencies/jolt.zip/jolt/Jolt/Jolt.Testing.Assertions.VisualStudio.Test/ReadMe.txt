The Jolt.NET project Jolt.Testing.Assertions.VisualStudio.Test requires a reference to Microsoft.VisualStudio.QualityTools.UnitTestFramework.dll for compilation and execution.  The license of this assembly restricts it from being distributed with Jolt.NET, and consequently you must obtain the appropriate version of Microsoft Visual Studio to successfully compile this project.

Resources:
http://www.microsoft.com/visualstudio/en-us/products/teamsystem/default.mspx