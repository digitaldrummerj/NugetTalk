The Jolt.NET projects Jolt.Automata.Glee and Jolt.Automata.Glee.Test require Microsoft GLEE assemblies for compilation and execution.  Due to the nature of the Microsoft GLEE license, Microsoft GLEE can not be distributed with Jolt.NET.  Consequently, you must obtain Microsoft GLEE and place any its binaries in this directory for successful compilation.

Resources:
http://research.microsoft.com/en-us/downloads/f1303e46-965f-401a-87c3-34e1331d32c5/default.aspx